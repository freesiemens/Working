# -*- coding: utf-8 -*-
"""
Created on Mon Jan 26 16:14:20 2015

@author: rbanderson
"""
import matplotlib.pyplot as plot
import numpy
import csv

def RMSE(RMSECV,RMSEP,RMSEC,plot_title,outfile,RMSEP_cals=None):
    plot.plot(range(1,len(RMSECV)+1),RMSECV,color='r',linewidth=2.0,label='RMSECV (folds)')
    plot.plot(range(1,len(RMSEC)+1),RMSEC,color='b',linewidth=2.0,label='RMSEC (training set)')
    plot.plot(range(1,len(RMSEP)+1),RMSEP,color='g',linewidth=2.0,label='RMSEP (test set)')
    if RMSEP_cals!=None:
        if numpy.max(RMSEP_cals[0])>0:        
            plot.plot(range(1,len(RMSEP_cals[0])+1),RMSEP_cals[0],color='m',linewidth=2.0,linestyle='-',label='RMSEP (KGa-MedS)')
        if numpy.max(RMSEP_cals[1])>0:        
            plot.plot(range(1,len(RMSEP_cals[1])+1),RMSEP_cals[1],color='m',linewidth=2.0,linestyle='--',label='RMSEP (Macusanite)')
        if numpy.max(RMSEP_cals[2])>0:
            plot.plot(range(1,len(RMSEP_cals[2])+1),RMSEP_cals[2],color='k',linewidth=2.0,linestyle='-',label='RMSEP (NAU2HIS)')
        if numpy.max(RMSEP_cals[3])>0:
            plot.plot(range(1,len(RMSEP_cals[3])+1),RMSEP_cals[3],color='k',linewidth=2.0,linestyle='--',label='RMSEP (NAU2LOS)')
        if numpy.max(RMSEP_cals[4])>0:
            plot.plot(range(1,len(RMSEP_cals[4])+1),RMSEP_cals[4],color='k',linewidth=2.0,linestyle=':',label='RMSEP (NAU2MEDS)')
        if numpy.max(RMSEP_cals[5])>0:
            plot.plot(range(1,len(RMSEP_cals[5])+1),RMSEP_cals[5],color='c',linewidth=2.0,linestyle='-',label='RMSEP (Norite)')
        if numpy.max(RMSEP_cals[6])>0:
            plot.plot(range(1,len(RMSEP_cals[6])+1),RMSEP_cals[6],color='c',linewidth=2.0,linestyle='--',label='RMSEP (Picrite)')
        if numpy.max(RMSEP_cals[7])>0:
            plot.plot(range(1,len(RMSEP_cals[7])+1),RMSEP_cals[7],color='c',linewidth=2.0,linestyle=':',label='RMSEP (Shergottite)')
        plot.plot(range(1,len(RMSEP_cals[8])+1),RMSEP_cals[8],color='k',linewidth=4.0,linestyle='-',label='RMSEP (Cal Targets In Range)')
        plot.plot(range(1,len(RMSEP_cals[8])+1),RMSEP_cals[8],color='y',linewidth=3.5,linestyle='-',label='RMSEP (Cal Targets In Range)')
        
        
        
        
    plot.legend()
    plot.title(plot_title)
    
    plot.ylim([numpy.min([RMSECV,RMSEP,RMSEC]),numpy.max([RMSECV,RMSEP,RMSEC])])
    if RMSEP_cals!=None:
        plot.ylim([numpy.min(numpy.vstack((RMSECV,RMSEP,RMSEC,RMSEP_cals))),numpy.max(numpy.vstack((RMSECV,RMSEP,RMSEC,RMSEP_cals)))])
    plot.xlabel('# of Components')
    plot.ylabel('wt.%')
    plot.xticks(range(1,len(RMSEC)+1))
    fig=plot.gcf()
    #fig.set_dpi(600)      
    fig.set_size_inches(11,8.5)
    fig.savefig(outfile)
    fig.clf()

def Plot1to1(truecomps,predicts,plot_title,labels,colors,markers,outfile,xminmax=[0,100],yminmax=[0,100],ylabel='Prediction (wt.%)',xlabel='wt.%',one_to_one=True):
    if one_to_one:
        plot.plot([0,100],[0,100],color='k',linewidth=2.0,label='1:1 line')
    for i in range(len(truecomps)):
        plot.plot(truecomps[i],predicts[i],color=colors[i],label=labels[i],marker=markers[i],linewidth=0)
    plot.xlabel(xlabel)
    plot.ylabel(ylabel)
    plot.xlim(xminmax)
    plot.ylim(yminmax)
    plot.legend(loc=2)
    plot.title(plot_title)
    fig=plot.gcf()
    #fig.set_dpi(600)
    fig.set_size_inches(11,8.5)
    fig.savefig(outfile)
    plot.close()

    
def readpredicts(filename,nc):
    f=open(filename,'rb')  #open the file
    cols=f.readline() #read the first line
    cols=numpy.array(cols.split(',')[1:]) 
    cols[-1]=cols[-1].replace('\r','')
    cols[-1]=cols[-1].replace('\n','')
    
    data=zip(*csv.reader(f))
    samples=numpy.array(data[0],dtype='string')
    spect_indexes=numpy.array(data[1],dtype='int')
    folds=numpy.array(data[2],dtype='int')
    truecomps=numpy.array(data[3],dtype='float')
    colmatch=numpy.squeeze(numpy.array(numpy.where(cols==str(nc))))
    predicts=numpy.array(data[colmatch],dtype='float')
    
    return predicts,samples,truecomps,folds,spect_indexes